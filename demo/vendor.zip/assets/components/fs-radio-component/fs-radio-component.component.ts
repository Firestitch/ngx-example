import { Component } from '@angular/core';

@Component({
  selector: 'fs-radio-component',
  templateUrl: 'fs-radio-component.component.html',
  styleUrl: 'fs-radio-component.component.css',
})
export class FsRadioComponent {

  constructor() {
  }
}