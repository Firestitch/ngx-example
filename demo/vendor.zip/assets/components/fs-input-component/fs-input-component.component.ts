import { Component } from '@angular/core';

@Component({
  selector: 'fs-input-component',
  templateUrl: 'fs-input-component.component.html'
})
export class FsInputComponent {

  constructor() {
  }
}